package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView textViewGossip;
    private Button buttonNewGossip;
    private EditText editTextMessage;
    private Button buttonSend;
    private String[] gossips = new String[] {
            "Chuck and Blair secretly got married in Monaco!",
            "Serena was seen shopping in Paris with a mysterious man!",
            "Blair won the fashion icon award last night!"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewGossip = findViewById(R.id.textView);
        buttonNewGossip = findViewById(R.id.newgossip);
        editTextMessage = findViewById(R.id.editTextTextPersonName);
        buttonSend = findViewById(R.id.send);

        buttonNewGossip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random random = new Random();
                textViewGossip.setText(gossips[random.nextInt(gossips.length)]);
            }
        });

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextMessage.setText("");
            }
        });
    }
}